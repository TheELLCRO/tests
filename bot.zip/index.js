var request = require("request");
var fs = require("fs")
const cheerio = require('cheerio');
var existposts = [];
var grouplist = [];
var whitelist = "Розыгрыши ; Раздачи баз для брута ; Steam ; Fortnite ; Origin ; Uplay ; PSN ; Minecraft ; CoC, Clash Royale ; Social Club ; Warface ; Battle.net ; SAMP ; Другие игры ; Соц. сети ; VK Coin ; Кошельки, идентификация ; Aliexpress, Wish ; Акки с балансом, бонусами ; Скрипты, сайты, домены ; Приватные читы ; Прокси, VPN ; Дедики ; Логи ; Другое ; Требуются спамеры ; Разработка сайтов ; Программирование ; Накрутка в соц. сетях ; Инсталлы, крипт, трафик ; Хостинг, аренда магазина ; Чек баз ; Платная графика ; Обмен средств ; Прокачка аккаунтов, фарм ; Ищу работу ; Ищу софт ; Способы заработка ; Криптовалюты ; Социальная инженерия ; Безопасность ; Раскрутка в соц. сетях ; Продвижение в Вконтакте ; Продвижение в Инстаграме ; Вирусология ; Социальные сети ; Работа с хэшами ; Kali  Linux ; Анонимность в интернете ; Работа с дедиками ; Веб уязвимости ; Скрипты, шеллы ; Эксплойты ; vBulletin ; Программные эксплойты ; MyBB ; SMF ; Wordpress ; Joomla ; DLE ; IPB ; Другие эксплойты ; SQLI, Dork Parsers ; Hash ; Private Keeper, UBC ; Крипторы ; Брут, Чекеры ; Парсеры, грабберы ; Спамеры, бомберы ; Автореггеры ; Работа с текстом, базами ; Работа с прокси ; Читы для Fortnite ; Гайды Fortnite ; Читы SAMP ; Minecraft ; Ваши истории ; iOS ; Android ; HTML, CSS, Javascript ; Уроки ; HTML шаблоны, лендинги ; SEO, продвижение ; PHP, MySQL ; Движки, фрейворки ; Скрипты сайтов ; Помощь и уроки PK/UBC ; Python ; C/C++ ; C# ; Delphi ; Уроки ; Работа с текстом ; Платная графика ; Новости сайта ; Халява ; Работа и услуги ; Тематические вопросы ; Статьи ; Софт ; Fortnite ; GTA SAMP ; Телефоны ; Сайтостроительство ; Программирование ; Работа форума"
const VkBot = require('node-vk-bot-api')
const bot = new VkBot("996dd2613914f2d629615b531993a398f4a0a21d05480f0b63a263f99eebc73bb95f0d3c285283bc348ff")
var code;

bot.command('!addbot', (ctx) => {
  if (grouplist.indexOf(ctx.message.peer_id)  == -1){
    grouplist.push(ctx.message.peer_id);
    fs.writeFile('groups.json', JSON.stringify(grouplist));
  }

})
bot.startPolling()

const regex = /\|href\|max\|(.*?)\|navigator\|/;

try {
  if (fs.existsSync('groups.json')) {
    grouplist= JSON.parse(fs.readFileSync('groups.json', 'utf8'))
  }
} catch(err) {
}


async function getId() {
  return new Promise((resolve, reject) => {
    request(
      {
        method: "GET",
        uri: "https://lolzteam.net/forums/-/index.rss",
        headers: {
          "User-Agent":
            "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11",
          Accept: "/",
          Connection: "keep-alive"
        }
      },
      (err, res, body) => {
        if (err) {
          return reject(err);
        }
        if ((codes = regex.exec(body)) !== null) {
          code = codes[1];
        }
        return resolve(code);
      }
    );
  });
}



async function getNews() {
  if (code == null)
    code = await getId();
  return new Promise((resolve, reject) => {
    request(
      {
        method: "GET",
        uri: `https://lolzteam.net/?_xfResponseType=json&order=post_date`,
        headers: {
          "User-Agent":
            "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11",
          Accept: "/",
          "content-type" : 'application/x-www-form-urlencoded',
          Connection: "keep-alive",
          Cookie: `xf_id=${code}`
        },
       },
      (err, res, body) => {
        if (err) {
          return reject(err);
        }
        if ((codes = regex.exec(body)) !== null) {
          code = codes[1];
          return reject("Code updated")
        }
        if (body.indexOf("templateHtml") == -1){
          console.log(body)
          return reject("Theme not Found")
        } 
        const $ = cheerio.load( JSON.parse(body)["templateHtml"],{
          withDomLvl1: true,
          normalizeWhitespace: true,
          xmlMode: true,
          decodeEntities: true
      })
      resolve($)
    
        }
    );
  });
}

async function sendTheme(nameThread,link,name){
  nameThread = nameThread.replace("vtope","вжопе")
  nameThread = nameThread.replace("vto.pe","вжопе")
  grouplist.forEach(id => {
    bot.sendMessage( id, `Новая тема: \n\n ${nameThread} \n https://lolzteam.net/${link}\n Автор: ${name}`);
  });
}

async function parse() {
  console.log("Темы в буфере: ",Object.keys(existposts).length)
  if (Object.keys(existposts).length == 0){
    getNews().then($ => {
      for (let i = 0; i < $(".PreviewTooltip").length; i++) {
        const link = $(".PreviewTooltip")[i].attribs.href;
        existposts[link] = true;
     }
    });
  }else{
    getNews().then($ => {
      for (let i = 0; i < $(".PreviewTooltip").length; i++) {
        const nameThread = $(".PreviewTooltip .title")[i].children[1].children[0].data;
        const link = $(".PreviewTooltip")[i].attribs.href;
        let name;
        try {
         name = $(".PreviewTooltip .username")[i].children[0].children[0].data
        } catch (error) {
          name = $(".PreviewTooltip .username")[i].children[0].data
        }
       const cat = $(".PreviewTooltip .threadNode")[i].children[0].data;
       if (!existposts[link]) {
       existposts[link] = true;
       if (whitelist.indexOf(cat)  != -1){
        sendTheme(nameThread,link,name);
       }
       };
     }
    });
  }
}


setInterval(async () => { 
  if (Object.keys(existposts).length > 100){
    existposts=[];
  }  
  await parse(); 

}, 5000)